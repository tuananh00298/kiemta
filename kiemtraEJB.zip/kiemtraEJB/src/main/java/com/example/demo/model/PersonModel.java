package com.example.demo.model;

import com.example.demo.entity.Person;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface PersonModel extends PagingAndSortingRepository<Person, Integer> {
}
